rm(list=ls())
library(R2admb)
library(glmmTMB)
library(doParallel)
library(R.utils)
library(pscl)

admb_dir = "/users/yangshi/projects/single_cell/zinbmm_sparse"

admb_file = '/users/yangshi/projects/single_cell/zinbmm_sparse/zinbmm_sparse'
tpl_file = '/users/yangshi/projects/single_cell/zinbmm_sparse/zinbmm_sparse.tpl'
admb_name = 'zinbmm_sparse'

setwd(admb_dir)
#set simulation parameters
alpha1=(-0.5)
beta1=1
sigma_u=0.5

alpha2=3
beta2=3
sigma_v=0.5
gamma=1.5

m=20 #number of clusters(patients) is 20
n=40 #cluster size (number of single cell samples from each patient) is 40

alpha1_hat=beta1_hat=sigma_u_hat=alpha2_hat=beta2_hat=sigma_v_hat=gamma_hat=if_converge=NA
alpha1_hat2=beta1_hat2=sigma_u_hat2=alpha2_hat2=beta2_hat2=sigma_v_hat2=gamma_hat2=if_converge2=NA

set.seed(1)
registerDoParallel(cores=8)
result = foreach(i = 1:1000, .combine=rbind) %dopar%
{
  #make a directory
  new_name = paste(admb_name,'_',i, sep='')
  dir=paste(admb_dir, '/', new_name, sep='')
  system(paste('mkdir', dir))
  
  new_program = paste(dir,'/', new_name,sep='')
  new_tpl = paste(dir,'/', new_name,'.tpl',sep='')

  #copy the admb program to the directory
  system(paste('cp', admb_file, new_program))
  system(paste('cp', tpl_file, new_tpl))
  
  #change R to the directory
  setwd(dir)
  
  ###########################################################################################################################################
  #begin the simulation
  #cluster level random effect
  u = rnorm(m, 0, sd=sigma_u)
  v = rnorm(m, 0, sd=sigma_v)
  
  #calculate the predictor
  zeta = c( rep(alpha1, times=(m/2)*n),rep((alpha1+beta1),times=(m/2)*n) ) + rep(u, each=n)
  eta = c( rep(alpha2, times=(m/2)*n),rep((alpha2+beta2),times=(m/2)*n) ) + rep(v, each=n)
  
  phi = exp(zeta)/(1+exp(zeta))
  mu = exp(eta)
  
  #Flip a coin to work out if the sample is from 0
  w = rbinom(n=(m*n),size=1,prob=phi)
  temp_y = rnbinom(n=(m*n), size=gamma, mu=mu)
  y = temp_y*(1-w)
  
  ZINB_data = data.frame(y=y, x=as.factor(c(rep(0,times=(m/2)*n), rep(1,times=(m/2)*n))) ,cluster=as.factor(rep((1:m), each=n)), id=(1:(m*n)))
  
  ###########################################################################################################################################
  #ADMB part:
  #estimate the initial value by ZINB without random effect
  fit1 = zeroinfl(y~x, data=ZINB_data, dist="negbin")
  coef_ini = coefficients(fit1)
  alpha1_ini = coef_ini[3]
  beta1_ini = coef_ini[4]
  alpha2_ini = coef_ini[1]
  beta2_ini = coef_ini[2]
  gamma_ini = fit1$theta
  
  #fixed effect design matrix
  mmf = model.matrix(~x, data=ZINB_data)
  #cluster indices
  cluster = rep(1:m, each=n)
  
  nf=ncol(mmf)
  
  regdata=list(n = n*m, m = m, nf = nf, fdesign=mmf, cluster=cluster, y=y)
  
  write_dat(new_name, L=regdata)
  
  regparams=list(fcoeffs1=c(alpha1_ini, beta1_ini),
                 fcoeffs2=c(alpha2_ini, beta2_ini),
                 gamma=gamma_ini,
                 sigma_u=1,
                 sigma_v=1,
                 scale_u=rep(0.01,m),
                 scale_v=rep(0.01,m))
  write_pin(new_name, L=regparams)
  
  system(paste('timeout 5m ', './', new_name, ' -shess -noinit -nox -l1 100000000 -l2 100000000 -l3 100000000 -nl1 100000000 -nl2 100000000 -nl3 100000000 -ilmn 5 -mcr 5 -maxfn 50 > allout.txt 2>&1', sep=''))
  
  if( !file.exists(paste(new_name, '.par', sep='')) ) #fail to give MLE
  {
    system(paste('pkill', new_name)) #make sure to stop the program
    if_converge[i]=0 
    alpha1_hat[i]=beta1_hat[i]=alpha2_hat[i]=beta2_hat[i]=sigma_u_hat[i]=sigma_v_hat[i]=gamma_hat[i]=NA
  }else
  {
    if_converge[i] = 1
    fit = read_admb(new_name)
    
    coefficients = coef(fit)
    alpha1_hat[i] = coefficients[1]
    beta1_hat[i] = coefficients[2]
    alpha2_hat[i] = coefficients[3]
    beta2_hat[i] = coefficients[4]
    sigma_u_hat[i] = coefficients[5]
    sigma_v_hat[i] = coefficients[6]
    gamma_hat[i] = coefficients[7]
  }
  
  clean_admb(new_name)
  
  ###########################################################################################################################################
  #TMB part
   tryCatch(
   expr={withTimeout({
      
       fit = glmmTMB(formula=y ~ x + (1|cluster), ziformula= ~ x + (1|cluster), data=ZINB_data, family=list(family="nbinom2",link="log"))
       if_converge[i] = 1 
      }, timeout=300) },
   TimeoutException = function(ex) print('Timeout fitting TMB.'),
   error = function(e) print("Error in fitting TMB.")
  )

  if(is.na(if_converge2[i])) #timeout or error in fitting TMB
  {
    if_converge2[i]=0 
    alpha1_hat2[i]=beta1_hat2[i]=alpha2_hat2[i]=beta2_hat2[i]=sigma_u_hat2[i]=sigma_v_hat2[i]=gamma_hat2[i]=NA
  }else #the model fitted successfully
  {
    coefficients2 = fit$fit$par
    alpha1_hat2[i] = coefficients2[3]
    beta1_hat2[i] = coefficients2[4]
    alpha2_hat2[i] = coefficients2[1]
    beta2_hat2[i] = coefficients2[2]
    sigma_u_hat2[i] = exp(coefficients2[6])
    sigma_v_hat2[i] = exp(coefficients2[7])
    gamma_hat2[i] = exp(coefficients2[5])
  }
  
  return(c(if_converge[i],alpha1_hat[i],beta1_hat[i],alpha2_hat[i],beta2_hat[i],sigma_u_hat[i],sigma_v_hat[i],gamma_hat[i],
           if_converge2[i],alpha1_hat2[i],beta1_hat2[i],alpha2_hat2[i],beta2_hat2[i],sigma_u_hat2[i],sigma_v_hat2[i],gamma_hat2[i]))
}

system(paste("rm -rf ", admb_name, '_*', sep=''))
save.image('zinbmm.RData')
